from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm

from app.database import engine, Base, get_db
from app import models, schemas, auth

Base.metadata.create_all(bind=engine)

app = FastAPI(title="API Incidencias")

@app.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends()):

    if (
        form_data.username != auth.fake_user["username"]
        or form_data.password != auth.fake_user["password"]
    ):
        raise HTTPException(status_code=400, detail="Credenciales incorrectas")

    token = auth.create_access_token(
        data={"sub": form_data.username}
    )

    return {"access_token": token, "token_type": "bearer"}


@app.get("/incidencias", response_model=list[schemas.Incidencia])
def get_incidencias(db: Session = Depends(get_db)):
    return db.query(models.Incidencia).all()


@app.post("/incidencias")
def crear_incidencia(
    incidencia: schemas.IncidenciaCreate,
    db: Session = Depends(get_db),
    user: str = Depends(auth.verify_token)
):
    nueva = models.Incidencia(**incidencia.dict())
    db.add(nueva)
    db.commit()
    db.refresh(nueva)
    return nueva


@app.get("/perfil")
def perfil(user: str = Depends(auth.verify_token)):
    return {"usuario": user}